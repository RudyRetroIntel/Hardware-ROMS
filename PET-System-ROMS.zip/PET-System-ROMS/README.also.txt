Below is the cross reference of part numbers you asked for.  I have
written it as a text file since writing an e-mail this long without
errors would be very difficult (at least for me).

   petbasic-4
          [ 901465-23 + 901465-20 + 901465-21 ]

   petbasic-4-unpatched
          [ 901465-19 ]

   petchars
          [ 901447-10 ]

   petedit-2-n
          [ 901447-24; also the same as 6540-024 ]

   petedit-4-40-b-noCRTC
          [ 901474-02 ]

   petedit-4-40-n-50Hz-reconstruc
          [ 901498-01 ]

   petedit-4-40-n-60Hz
          [ 901499-01 ]

   petedit-4-40-n-noCRTC
          [ 901447-29 ]

   petedit-4-80-b-50Hz
          [ 901474-04 ]

   petedit-4-80-b-60hz
          [ 901499-01 ]

   petkernel-4
          [901465-22]

   petrom-1
          [ 901447-09 + 901447-02 + 901447-03 + 901447-04 +
            901447-05 + 2K of fill + 901447-06 + 901447-07
                          also the same as
            901439-09 + 901439-05 + 901439-02 + 901439-06 +
            901439-03 + 2K of fill + 901439-04 + 901439-07 ]

   petrom-2-b
          [ 901465-01 + 901456-02 + 901474-01 + 2K of fill + 901465-03
                          also the same as
            6540-020 + 6540-021 + 6540-022 + 6540-023 +
            no equivalent + 2K of fill + 6540-025 + 6540-026]


The table below, from the information file in the PET section, can be
interpreted as follows:

  The three digits before the decimal point are the 6540 suffix.  The
  digits after the decimal point are a date code.  For instance,
  018.4378A is a 6540-018 made the 43rd week of 1978

> $F800-FFFF  018.4378A
> $D800-DFFF  014.4278A
> $C800-CFFF  012.4278A
> $F000-F7FF  016.4478A
> $E000-E7FF  015.4478A
> $D000-D7FF  013.4478A
> $C000-C7FF  019.1878A


The two tables below, from the same file, present a problem.  I can vouch
for the ROM numbers in the first table since I have a computer with those
ROMs in it.  I also have service information on that machine from before
the upgrade was issued.  This information uses the part numbers in the
first table as the numbers for the ROMs in the first table.  Unless
Commodore issued two different sets of ROMs using the same part number,
the part numbers in the second table are wrong.


>  Location  ROM      Part Number
>  ------------------------------
>        H1  6540-019  901439-09
>        H2  6540-013  901439-02
>        H3  6540-015  901439-03
>        H4  6540-016  901439-04
>        H5  6540-012  901439-05
>        H6  6540-014  901439-06
>        H7  6540-018  901439-07
>        A2  6540-010  901439-08 [character generator]


As noted above, the following table has problems.  The part numbers cannot
be right.  I have other documentation that confirms that the ROM numbers
below are for Basic 2, the same as that in the 2001-N.  Commodore's
replacement parts list uses the part numbers according to the table below,
however that list is notoriously unreliable and should not be depended
upon without other confirmation.


>  Location  ROM      Part Number
>  ------------------------------
>        H1  6540-020  901439-09
>        H2  6540-022  901439-02
>        H3  6540-024  901439-03
>        H4  6540-025  901439-04
>        H5  6540-021  901439-05
>        H6  6540-023  901439-06
>        H7  6540-026  901439-07
