To the best of my knowledge, the following variation of PET ROM sets
exist:

-   Basic 1.0
    These all have a "chicklet" keyboard, functionally identical
    to the N keyboard, no CRT controller chip, 60 Hz refresh,
    40 columns.

-   Basic 2.0
    -   with N keyboard (Normal, or Graphic)
    -   with B keyboard (Business, without graphic symbols)

-   Basic 4.0
    -   with N keyboard (Normal, or Graphic)
    -   with B keyboard (Business, without graphic symbols)
    and
    -   as upgrade for machines without CRT controller
    -   for new machines with CRT controller
    and
    -   40 columns
    -   80 columns
    and
    -   50 Hz screen refresh (and IRQ)
    -   60 Hz screen refresh (and IRQ)

    Fortunately not all combinations exist, but there are still a lot.

    -   no CRTC implies 60 Hz and 40 columns.
    -   80 columns implies CRTC and B keyboard, although N versions
        have been made by 3rd parties.


My naming convention is as follows:

-   Files containing a complete set are called petrom*
-   Files with only the Basic part (B000 or C000-E000) are petbasic*
-   Files with only the Kernel part (F000-0000) are petkernel*
-   Files with only the "Screen Editor" part (E000-E800) are petedit*

-   1.0 is -1
-   2.0 is -2
-   4.0 is -4

-   N keyboard is -n
-   B keyboard is -b
    The differences are the keyboard scan codes, and keyboard decoding.
    On the N version all keys are "shiftable", on the B version only
    123456789:-;,./ . These keys have their petscii value exclusive-
    or'd with $20 when shifted. A-Z are eor'd with $80.
    These differences lead to different lengths of decoding code,
    which moves the scancode table, the text for shift-stop (either
    load<cr>run<cr>, lO<cr>rU<cr>, or dL"*<cr>run<cr>), and the table
    with pointers to screen lines (for 40 column versions).

-   The screen refresh rate (and IRQ) is only mentioned for CRTC machines.
    1.0 and 2.0 are only 60 Hz, 50 Hz is -50hz, and 60 Hz is -60hz.
    The 50 Hz versions with CRTC have a patch in the IRQ routine which
    increments the jiffy timer by 1 extra every 5 interrupts, and the
    CRTC parameters are slightly different. (From this, I edited
    petedit-4-40-n-60Hz into petedit-4-40-n-50Hz with reference to a
    printed disassembly)

-   Default for 4.0 is CRTC, the upgrade roms are -noCRTC.
    The -4-noCRTC version does not have the function jump table at the
    start that the -4-CRTC versions have. Therefore it seems more
    compatible to directly jump to the relevant functions in the editor
    rom since many of them start at the same place in all versions.

-   I discovered in the 4-80-b-60hz version that it had a slightly
    different basic Bxxx ROM. All other versions had some patches added.
    I include the apparently unpatched version as -unpatched.

Apart from basic and kernel, there is also the character rom,
part number 901447-10 (in fat-40, 8032sk, 8296). It appears to contain
only the not-reversed characters.

In this collection are:

petrom-1                   16386 ----rwed 30-Jan-95 22:40:15
petrom-2-b                 16386 ----rwed 29-Jan-95 23:46:44
petedit-2-n                 2051 ----rwed 06-Jun-95 21:54:21

petbasic-4                 12290 ----rwed 01-Jan-95 18:08:56
	901465-23 + 901465-20 + 901465-21 (in fat-40, 8032sk)
	324878-01lo + 324878-01hi (8296, contains kernel+basic)
petbasic-4-unpatched        4098 ----rwed 31-Jan-95 02:11:08
	901465-19 ?
petedit-4-40-b-noCRTC       2050 ----rwed 31-Jan-95 02:38:19
petedit-4-40-n-50Hz-reconstruc    2050 ----rwed Today     23:37:52
petedit-4-40-n-60Hz         2050 ----rwed 11-Feb-95 15:59:43
	901499-01 (in fat-40)
petedit-4-40-n-noCRTC       2050 ----rwed 30-Jan-95 22:15:42
petedit-4-80-b-50Hz         2050 ----rwed 01-Jan-95 18:09:28
	901474-04 (in 8032sk, 8296)
petedit-4-80-b-60hz         2050 ----rwed 31-Jan-95 02:46:02
petedit-4-80-b.dis         35031 ----rwed 28-Feb-95 21:16:55
petkernel-4                 4098 ----rwed 01-Jan-95 18:11:39
	901465-22 (fat40, 8032sk)
	324878-01lo + 324878-01hi (8296, contains kernel+basic)

If you have any versions not in this collection, I would like to
hear from you:

    petedit-4-40-b-50Hz
    petedit-4-40-b-60Hz
    petedit-4-40-n-50Hz


Pete Turnbull <pnt103@student1.cs.york.ac.uk> reports:

> Hi, Olaf.  Here is the information about the ROMs in my two PETs.  The "new"
> one is a 32K dynamic-RAM machine with "proper" keyboard (and numeric keypad)
> but no built-in cassette, and has been upgraded with Series 4000 ROMs (BASIC
> 4) and a Toolkit.  The "old" one is an original 2001-8K static-RAM machine
> with "calculator" keyboard and built-in cassette, and the original ROMs.
> 
> In a "new-ROM" 2001-series 16K/32K CBM, there are 7 ROM sockets and a 74154
> decoder in a row.  All the sockets take 2332 or 8513 ROMs or Texas 2532 (NOT
> Intel 2532) EPROMs (4K x 8).  The Series 4000 machines are very similar,
> except that the sockets run front-to-back rather than left-to-right. 
> Looking from the front of the machine, with pin-1 of each I.C. nearest the
> viewer, the sockets are, from left to right (front-to-back on Series 4000):
> 
> $F000-FFFF  901465-22
> $E000-EFFF  901447-29
> $D000-DFFF  901465-21
> $C000-CFFF  901465-20
> $B000-BFFF  901465-23
> $A000-AFFF  spare       used for Toolkit ROM, etc
> $9000-9FFF  spare
> 
> In an "old-ROM" PET 2001-8K, there are 7 ROM sockets in a row.  All take MOS
> Technology MCS6540 ROMs (2K x 8) which are not compatible with any other
> ROM/EPROM I know!  Looking from the front of the machine, with pin-1 of each
> I.C. nearest the viewer, the sockets are, from left to right:
> 
> $F800-FFFF  018.4378A
> $D800-DFFF  014.4278A
> $C800-CFFF  012.4278A
> $F000-F7FF  016.4478A
> $E000-E7FF  015.4478A
> $D000-D7FF  013.4478A
> $C000-C7FF  019.1878A
> 
> Pete

I have the following from PBE (Pet Benelux Exchange) issue 1980-2
(including apparent inconsistencies):

When the PET 2001 went into production for the first time in 1977 there
were two ROM sets available for the system. The firt ROM set is of
the type 6540. This is a 28 pins ROM produced by MOS Technology. These
ROMs are placed in the following locations of the PET 2001-4 and 2001-8
motherboard:

  Location  ROM      Part Number
  ------------------------------
	H1  6540-019  901439-09 
	H2  6540-013  901439-02 
	H3  6540-015  901439-03 
	H4  6540-016  901439-04 
	H5  6540-012  901439-05 
	H6  6540-014  901439-06 
	H7  6540-018  901439-07 
	A2  6540-010  901439-08 [character generator, I think -rhialto]

Note: There is a 019-ROM at location H1. On earlier motherboards there is
a 6540-11 at H1. This ROM has been replaced by a 019 because there was
an intermittent bug in the 'edit software'. We call this ROM set Basic
level I.

The other ROM set for the PET 2001 is of type 2316B, a 24 pens ROM.
  
  Location  Part Number
  ------------------------------
	H1  901447-09 
	H2  901447-03 
	H3  901447-05 
	H4  901447-06 
	H5  901447-02 
	H6  901447-04 
	H7  901447-07 
	A2  901439-08 [character generator, I think -rhialto]

[Same remark about -09 being a preplacement for -01]

The following ROM sets can be used as replacements to upgrade to
Basic level II, for 6540 motherboards:

  Location  ROM      Part Number
  ------------------------------
	H1  6540-020  901439-09 
	H2  6540-022  901439-02 
	H3  6540-024  901439-03 
	H4  6540-025  901439-04 
	H5  6540-021  901439-05 
	H6  6540-023  901439-06 
	H7  6540-026  901439-07 

Same for 2316B ROMs:

  Location  Part Number
  ------------------------------
	H1  901465-01 
	H2  901465-02 
	H3  901447-24 
	H4  901465-03 
	H5  blank
	H6  blank
	H7  blank

So far the 'old' 8K with it possibly rejuvenated heart. The following
ROM sets are now being produced. There are two sets being used. If you
have a "graphic" PET you'll find the following ROM set:

[this is called the 3001 series in Europe but still 2001-16 and
2001-32 in the USA, anyway the first with "proper" keyboard" -rhi]

  Location  Part Number
  ------------------------------
	D3  blank
	D4  blank
	D5  blank
	D6  901465-01 
	D7  901465-02 
	D8  901447-24 
	D9  901465-03 
	F10 901447-10

If you have a 'business' type with different keyboard without the graphic
symbols, then the following ROMs are present:

  Location  Part Number
  ------------------------------
	D3  blank
	D4  blank
	D5  blank
	D6  901465-01 
	D7  901465-02 
	D8  901474-01 	[this one differs -rhialto]
	D9  901465-03 

The ROMs in the graphic and business PET are Basic level II ROMs.

Old ROMs (level I, or 1.0)  *** COMMODORE BASIC ***
New ROMs (level II, or 2.0) ### COMMODORE BASIC ###

David Gahris <dgahris@eece.maine.edu> reports:

> 901447-10
> Character generator from a Fat Forty.  I have no way of telling the serial
> number.
>
> 901499-01
> I don't know what this is, but I am curious.  :-)

Fat-40 60 Hz N keyboard (petedit-4-40-n-60Hz)


-Olaf.
--
___ Olaf 'Rhialto' Seibert    rhialto@mbfys.kun.nl         What's the use of
\X/  racism if you can't even see if a person belongs to your abhorred kind?
